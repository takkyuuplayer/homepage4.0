# ページに表示されているフォロアーを全員フォローするスクリプト
require 'rubygems'
require 'watir'

def show(msg, title)
  wsh = WIN32OLE.new('WScript.Shell')
  wsh.Popup(msg, 0, title, 0 + 64 + 0x40000)
end

browser = Watir::IE.start  "http://www.google.co.jp/ig"
browser.text_field(:id, "q").set("takkyuuplayer")
browser.button(:value,"Google 検索").click
browser.link(:text, "勉強支援").click
browser.link(:text, "AutoIE").click

show("サンプルプログラムを終了します", "message")