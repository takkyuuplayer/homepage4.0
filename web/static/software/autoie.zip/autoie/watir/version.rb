module Watir
  class IE
    VERSION = '1.6.5'
  end
end
